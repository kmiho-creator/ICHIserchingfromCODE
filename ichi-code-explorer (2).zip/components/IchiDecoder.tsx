
import React from 'react';
import { SearchMode } from '../types';

interface IchiDecoderProps {
  mode: SearchMode;
  combinedInput: string;
  setCombinedInput: (val: string) => void;
  stems: string[];
  setStems: (val: string[]) => void;
  extensions: string[];
  setExtensions: (val: string[]) => void;
}

export const IchiDecoder: React.FC<IchiDecoderProps> = ({
  mode,
  combinedInput,
  setCombinedInput,
  stems,
  setStems,
  extensions,
  setExtensions,
}) => {
  const updateStem = (idx: number, val: string) => {
    const next = [...stems];
    next[idx] = val;
    setStems(next);
  };

  const updateExtension = (idx: number, val: string) => {
    const next = [...extensions];
    next[idx] = val;
    setExtensions(next);
  };

  if (mode === SearchMode.COMBINED) {
    return (
      <div className="space-y-4">
        <label className="block text-sm font-semibold text-slate-700 mb-2">
          連結済みコードを入力してください
        </label>
        <div className="relative">
          <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none text-slate-400">
            <i className="fas fa-barcode"></i>
          </div>
          <input
            type="text"
            className="w-full pl-12 pr-4 py-4 border-2 border-slate-100 rounded-2xl bg-slate-50 focus:bg-white focus:border-blue-500 focus:ring-4 focus:ring-blue-100 transition-all outline-none text-lg font-mono placeholder:text-slate-300"
            placeholder="AZZ.ZY.ZY & XG3R70"
            value={combinedInput}
            onChange={(e) => setCombinedInput(e.target.value)}
          />
        </div>
        <p className="text-xs text-slate-400 italic">
          ※ Stemコード(XXX.YY.ZZ) と Extensionコード(XXXXXX) を 「&」 でつなげて入力できます。
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div>
        <label className="block text-sm font-semibold text-blue-800 mb-3 flex items-center gap-2">
          <span className="bg-blue-100 p-1.5 rounded-lg inline-flex items-center justify-center w-6 h-6 text-[10px]">1</span>
          Stem Codes (最大3つ)
        </label>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {stems.map((s, i) => (
            <div key={i} className="relative group">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400 group-focus-within:text-blue-500 transition-colors">
                <i className="fas fa-tag text-xs"></i>
              </div>
              <input
                type="text"
                className="w-full pl-9 pr-3 py-3 border border-slate-200 rounded-xl bg-white focus:border-blue-500 focus:ring-2 focus:ring-blue-100 transition-all outline-none font-mono text-sm uppercase"
                placeholder="XXX.YY.ZZ"
                value={s}
                onChange={(e) => updateStem(i, e.target.value)}
              />
            </div>
          ))}
        </div>
      </div>

      <div>
        <label className="block text-sm font-semibold text-purple-800 mb-3 flex items-center gap-2">
          <span className="bg-purple-100 p-1.5 rounded-lg inline-flex items-center justify-center w-6 h-6 text-[10px]">2</span>
          Extension Codes (最大5つ)
        </label>
        <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
          {extensions.map((e, i) => (
            <div key={i} className="relative group">
              <input
                type="text"
                className="w-full px-3 py-3 border border-slate-200 rounded-xl bg-white focus:border-purple-500 focus:ring-2 focus:ring-purple-100 transition-all outline-none font-mono text-xs text-center uppercase"
                placeholder="XXXXXX"
                value={e}
                onChange={(ev) => updateExtension(i, ev.target.value)}
              />
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
