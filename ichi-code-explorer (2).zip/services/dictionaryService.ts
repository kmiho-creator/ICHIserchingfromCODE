
import { IchiDictionaryEntry } from "../types";
import { ICHI_DICTIONARY } from "../constants/dictionary";

export class DictionaryService {
  // 起動時に内蔵データを保持、CSV読み込み時に拡張されるMap
  private static cache: Map<string, string> = new Map();
  private static isInitialized: boolean = false;

  /**
   * 辞書の初期化（内蔵データのロード）
   */
  static init(): number {
    if (this.isInitialized) return this.cache.size;
    
    // 内蔵定数からデータを流し込む
    ICHI_DICTIONARY.forEach(entry => {
      this.cache.set(entry.code, entry.description);
    });
    
    this.isInitialized = true;
    return this.cache.size;
  }

  /**
   * CSV文字列を解析して現在のセッションに追加（リロードで消える）
   */
  static addFromCSV(csvText: string): number {
    const lines = csvText.split(/\r?\n/);
    let addedCount = 0;
    
    lines.forEach(line => {
      // カンマ区切り、引用符対応の簡易パース
      const parts = line.split(/,(?=(?:(?:[^"]*"){2})*[^"]*$)/);
      if (parts.length >= 2) {
        const code = parts[0].replace(/"/g, '').trim();
        const desc = parts[1].replace(/"/g, '').trim();
        if (code && desc) {
          this.cache.set(code, desc);
          addedCount++;
        }
      }
    });
    return addedCount;
  }

  /**
   * コードの完全一致検索
   */
  static lookup(code: string): string | undefined {
    return this.cache.get(code);
  }

  static getSize(): number {
    return this.cache.size;
  }

  /**
   * 全データをリセットして初期状態（内蔵データのみ）に戻す
   */
  static resetToDefault() {
    this.cache.clear();
    this.isInitialized = false;
    return this.init();
  }
}
